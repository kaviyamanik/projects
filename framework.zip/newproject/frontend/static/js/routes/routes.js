import Home from "../views/Home.js";
import ReadMe from "../views/ReadMe.js";
import Application from "../views/Application.js";



export const routes = [
    { path: "/", view: Home },
    { path: "/readme", view: ReadMe },
    { path: "/application", view: Application },
];