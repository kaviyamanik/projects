import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Home");
    }

    async getHtml() {
        return `<main class="logo">
        <div class="container">
         <div class="loader"><span></span></div> 
         <div class="box"> 
         <div class="cube"></div> </div></div></main>`;    
    }
}