import AbstractView from "./AbstractView.js";
import DOMHELPER from '../DOM/DOMHelper.js';

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Application");
        this.id = 0;
    }


    displayToDo(element){
        const todos = this.getToDosFromLocalStorage();
        todos.forEach((todo) => this.addToDoList(element, todo.text, todo.id, todo.completed));
    }


    addToDoList(element, toDo, id, ifChecked){
        const completed = ifChecked ? 'checkedLine' : '';
        const statusIcon = ifChecked ? 'fa-check-circle' : 'fa-circle';
        const listItemEL = DOMHELPER.createElement('li');
        const pEL = DOMHELPER.createElement('p', {}, ['text', completed]);
        pEL.textContent = toDo;
        const completeIcon = DOMHELPER.createElement('i', {id, action: 'complete'}, ['far', statusIcon, 'co']);
        completeIcon.addEventListener('click', (e) => this.completeToDo(completeIcon));
        const deleteIcon = DOMHELPER.createElement('i', {id, action: 'delete'}, ['far', 'fa-trash-alt']);
        deleteIcon.addEventListener('click', () => this.removeToDo(deleteIcon));
        listItemEL.append(pEL);
        listItemEL.append(completeIcon);
        listItemEL.append(deleteIcon);
        element.append(listItemEL);
    }



    getToDosFromLocalStorage(){
        let todos;
        if(localStorage.getItem('toDo') === null){
            todos = [];
        }else{
            todos = JSON.parse(localStorage.getItem('toDo'));
        }
        return todos;

    }

    addToDoLocalStorage(toDo, id){
        const todos = this.getToDosFromLocalStorage();
        todos.push({
            text: toDo,
            id: id,
            completed: false
        });
        localStorage.setItem('toDo', JSON.stringify(todos));
    }

    removeToDo(element){
    
        element.parentNode.parentNode.removeChild(element.parentNode);
        
        const curId = element.attributes.id.value;
        const todos = this.getToDosFromLocalStorage();
        todos.forEach((todo, index) => {
            if(+todo.id === +curId){
                todos.splice(index, 1);
            }
        });
        localStorage.setItem('toDo', JSON.stringify(todos));
    }

    completeToDo(element){
        const CHECK = "fa-check-circle";
        const UNCHECK = "fa-circle";
        element.classList.toggle(CHECK);
        element.classList.toggle(UNCHECK);
        element.parentNode.querySelector(".text").classList.toggle("checkedLine");
        
        const curId = element.attributes.id.value;
        const todos = this.getToDosFromLocalStorage();
        todos.forEach((todo,index) => {
            if(+todo.id === +curId){
                todos[index].completed = todos[index].completed ? false : true;
            }
        });
        localStorage.setItem('toDo', JSON.stringify(todos));
    }

    clearToDo(){
        list.innerHTML = '';
        localStorage.clear();
    }

    async getHtml() {
        const containerEL = DOMHELPER.createElement('div', {}, ['container-app']);
        const headerEL = DOMHELPER.createElement('div', {}, ['header']);
        const h4EL = DOMHELPER.createElement('h4');
        h4EL.textContent = 'To Do List';
        const clearEl = DOMHELPER.createElement('div', {}, ['clear']);
        const clearIcon = DOMHELPER.createElement('i', {}, ['fas', 'fa-sync-alt']);
        clearIcon.addEventListener('click', this.clearToDo);
        const dateDiv = DOMHELPER.createElement('div', {id : 'date'});
        const options = {weekday: "long", month: "short", day: "numeric"}
        const today = new Date();
        dateDiv.innerHTML = today.toLocaleDateString("en-US", options);
        clearEl.append(clearIcon);
        headerEL.append(h4EL);
        headerEL.append(clearEl);
        headerEL.append(dateDiv);
        const contentEl = DOMHELPER.createElement('div', {}, ['content']);
        const ulEL = DOMHELPER.createElement('ul', {id : 'list'});
        contentEl.append(ulEL);
        const addToDoDiv = DOMHELPER.createElement('div', {}, ['add-to-do']);
        const iEL = DOMHELPER.createElement('i', {}, ['fas', 'fa-plus-circle', 'co']);
        const inputEL = DOMHELPER.createElement('input', {type: 'text', id: 'input', placeholder: 'Add New Item'});

        inputEL.addEventListener('keyup', (e) => {
            if(e.keyCode == 13){
                const toDoItem = input.value;
                if(toDoItem){
                    const curDate = Date.now()
                    this.addToDoList(ulEL, toDoItem, curDate);
        
                    this.addToDoLocalStorage(toDoItem, curDate);
                    this.id++;
                }
                input.value = "";
            }
        })

        addToDoDiv.append(iEL);
        addToDoDiv.append(inputEL);
        containerEL.append(headerEL);
        containerEL.append(contentEl);
        containerEL.append(addToDoDiv);

        this.displayToDo(ulEL);
        return containerEL;
    }
}
