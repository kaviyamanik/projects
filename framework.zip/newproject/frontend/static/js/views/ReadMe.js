import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("ReadMe");
    }

    async getHtml() {
        return `<div class="bg">
                    <div class="heading">
                        <h1>SpeedJS</h1>
                    </div>
                </div>
                <div class="instruct">
                    <ul>
                        <li><p>SpeedJS is a JavaScript Framework for building User Interfaces.</p></li>
                        <li><p>Used to build single page applications and Websites.</p></li>
                        <li><p>Run this command to execute the SppedJS application or website.</p></li>
                        <li><p>C:\\Users\\Your Name\\Your Ptoject Name> node server.js</p></li>
                        <li><p>Then open your browser and type localhost : 8084 in the address bar.</p></li>
                        <li><p>The Result:</p></li>
                    </ul>
                    <img  class="image" src="/static/css/images/home.jpg" width=50% height=50%>
                    <ul>
                        <li><p>Before starting with SpeedJS, you should have intermediate exerience in:</p></li>
                        <li><p>HTML</p></li>
                        <li><p>CSS</p></li>
                        <li><p>JavaScript</p></li>
                        <li><p>Within the frontend folder it has index.html file.<p></li>
                    </ul>
                    <img class="image" src="/static/css/images/index.jpg">
                    <ul><li><p>In this html file it has navigation links for Home, ReadMe and Application.</p></li></ul>
                    <img class="image" src="/static/css/images/imgnav.jpg" width=40%>
                    <ul>
                        <li><p>You can change it as your wish.</p></li>
                        <li><p>Within css folder it has index.css file and images folder.</p></li>
                        <li><p>You can change or add your styles and images.</p></li>
                    </ul>
                    <img class="image" src="/static/css/images/imgcss.jpg">
                    <ul>
                        <li><p>Within js folder it has three folders.</p></li>
                        <li><p>1. DOM </p></li>
                        <li><p>2. routes</p> </li>
                        <li><p>3. views</p></li>
                    </ul>
                    <img class="image" src="/static/css/images/imgjs.jpg">
                    <ul><li><p>1. Within DOM folder it has DOMHelper.js file. </p></li></ul>
                    <img class="image" src="/static/css/images/imgdom.jpg">
                    <ul><li><p>2. Within routes folder it has two js files that are router and routes.</p></li></ul>
                    <img class="image" src="/static/css/images/imgroute.jpg"><br>
                    <ul>
                        <li><p>You should use only routes.js file.</p></li>
                        <li><p>You can add or change this routes depending upon your navigation link. </p></li>
                    </ul>
                    <img class="image" src="/static/css/images/imgroutedemo.jpg"><br>
                    <ul><li><p>Before creating routes you should create a specified js class file in views folder like this.</p></li></ul>
                    <img class="image" src="/static/css/images/imgviewdemo.jpg"><br>
                    <ul><li><p>3. Within views folder you can maintain any number of js files as your wish.</p></li></ul>
                    <img class="image" src="/static/css/images/imgviews.jpg"><br>
                    <ul>
                        <li><p>In Views folder it has four js files. That are</p></li>
                        <li><p>1. AbstractView.js</p></li>
                        <li><p>2. Home.js</p></li>
                        <li><p>3. ReadMe.js</p></li>
                        <li><p>4. Application.js</p></li>
                        <li><p>1. AbstractView is used to set title for each and every navigation link as in your html file.</p></li>
                    </ul>
                    <img class="image" src="/static/css/images/imgabstract.jpg"><br>
                    <ul>
                        <li><p>2. Home is the home page page of this framework. It display the Framework Logo.</P></li>
                        <li><p>3. This ReadMe page gives instructions and informations to you. </p></li>
                        <li><p>4. Application page display the To-Do app for sample.</p></li>
                    </ul>
                    <img class="image" src="/static/css/images/imgtodo.jpg" width=40% height=50%> <br>
                    <ul>
                        <li><p>You can make your own applications and websites with the help of DOMHelper.</p></li>
                        <li><p>You need to write your own DOM for your application like this.</p></li>
                    </ul>
                    <img class="image" src="/static/css/images/imgdomdemo.jpg" width=40% height=50%> <br>
                    <ul>
                        <li><p>After creating this js file you should create particular route in routes.js file. </p></li>
                        <li><p>After completing all these steps you should run the server using node server.js command in the terminal.</li>
                        <li><p>Then open the browser and type localhost : 8084 as said earlier.</p></li>
                </div>
                `;
                
    }
}