export default class DOMHELPER  {
    constructor(){}


    static createElement(elName, attributes = {}, classes = []){
        const element = document.createElement(elName);
        for(const x in attributes){
            element.setAttribute(x, attributes[x])
        }
        for(const x of classes){
            if(x)
            element.classList.add(x)
        }
        return element;
    }
}     