﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class list
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MEDICINECATEGORIESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FEVERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.THYROIDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DIADETICSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CUSTOMERCATEGORIESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DAILYToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MONTHLYToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EMPLOYEEDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DOCTORSDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DETAILSToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SOLDMEDICINEDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DETAILSToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PHARMACYWHOLESALERSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PHARMAHOPERSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EXITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MEDICINECATEGORIESToolStripMenuItem, Me.CUSTOMERCATEGORIESToolStripMenuItem, Me.EMPLOYEEDETAILSToolStripMenuItem, Me.DOCTORSDETAILSToolStripMenuItem, Me.SOLDMEDICINEDETAILSToolStripMenuItem, Me.PHARMACYWHOLESALERSToolStripMenuItem, Me.EXITToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1138, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MEDICINECATEGORIESToolStripMenuItem
        '
        Me.MEDICINECATEGORIESToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.water_1330252__340
        Me.MEDICINECATEGORIESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FEVERToolStripMenuItem, Me.THYROIDToolStripMenuItem, Me.DIADETICSToolStripMenuItem})
        Me.MEDICINECATEGORIESToolStripMenuItem.Name = "MEDICINECATEGORIESToolStripMenuItem"
        Me.MEDICINECATEGORIESToolStripMenuItem.Size = New System.Drawing.Size(143, 20)
        Me.MEDICINECATEGORIESToolStripMenuItem.Text = "MEDICINE CATEGORIES"
        '
        'FEVERToolStripMenuItem
        '
        Me.FEVERToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.lime_2481346__340
        Me.FEVERToolStripMenuItem.Name = "FEVERToolStripMenuItem"
        Me.FEVERToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.FEVERToolStripMenuItem.Text = "FEVER"
        '
        'THYROIDToolStripMenuItem
        '
        Me.THYROIDToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.water_1330252__340
        Me.THYROIDToolStripMenuItem.Name = "THYROIDToolStripMenuItem"
        Me.THYROIDToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.THYROIDToolStripMenuItem.Text = "THYROID"
        '
        'DIADETICSToolStripMenuItem
        '
        Me.DIADETICSToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.lime_2481346__340
        Me.DIADETICSToolStripMenuItem.Name = "DIADETICSToolStripMenuItem"
        Me.DIADETICSToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DIADETICSToolStripMenuItem.Text = "DIABETICS"
        '
        'CUSTOMERCATEGORIESToolStripMenuItem
        '
        Me.CUSTOMERCATEGORIESToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.lime_2481346__340
        Me.CUSTOMERCATEGORIESToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DAILYToolStripMenuItem, Me.MONTHLYToolStripMenuItem})
        Me.CUSTOMERCATEGORIESToolStripMenuItem.Name = "CUSTOMERCATEGORIESToolStripMenuItem"
        Me.CUSTOMERCATEGORIESToolStripMenuItem.Size = New System.Drawing.Size(150, 20)
        Me.CUSTOMERCATEGORIESToolStripMenuItem.Text = "CUSTOMER CATEGORIES"
        '
        'DAILYToolStripMenuItem
        '
        Me.DAILYToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.water_1330252__340
        Me.DAILYToolStripMenuItem.Name = "DAILYToolStripMenuItem"
        Me.DAILYToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.DAILYToolStripMenuItem.Text = "DAILY"
        '
        'MONTHLYToolStripMenuItem
        '
        Me.MONTHLYToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.lime_2481346__340
        Me.MONTHLYToolStripMenuItem.Name = "MONTHLYToolStripMenuItem"
        Me.MONTHLYToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.MONTHLYToolStripMenuItem.Text = "MONTHLY"
        '
        'EMPLOYEEDETAILSToolStripMenuItem
        '
        Me.EMPLOYEEDETAILSToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.water_1330252__340
        Me.EMPLOYEEDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DETAILSToolStripMenuItem})
        Me.EMPLOYEEDETAILSToolStripMenuItem.Name = "EMPLOYEEDETAILSToolStripMenuItem"
        Me.EMPLOYEEDETAILSToolStripMenuItem.Size = New System.Drawing.Size(123, 20)
        Me.EMPLOYEEDETAILSToolStripMenuItem.Text = "EMPLOYEE DETAILS"
        '
        'DETAILSToolStripMenuItem
        '
        Me.DETAILSToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.lime_2481346__340
        Me.DETAILSToolStripMenuItem.Name = "DETAILSToolStripMenuItem"
        Me.DETAILSToolStripMenuItem.Size = New System.Drawing.Size(123, 22)
        Me.DETAILSToolStripMenuItem.Text = "DETAILS.."
        '
        'DOCTORSDETAILSToolStripMenuItem
        '
        Me.DOCTORSDETAILSToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.lime_2481346__340
        Me.DOCTORSDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DETAILSToolStripMenuItem1})
        Me.DOCTORSDETAILSToolStripMenuItem.Name = "DOCTORSDETAILSToolStripMenuItem"
        Me.DOCTORSDETAILSToolStripMenuItem.Size = New System.Drawing.Size(121, 20)
        Me.DOCTORSDETAILSToolStripMenuItem.Text = "DOCTOR'S DETAILS"
        '
        'DETAILSToolStripMenuItem1
        '
        Me.DETAILSToolStripMenuItem1.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.water_1330252__340
        Me.DETAILSToolStripMenuItem1.Name = "DETAILSToolStripMenuItem1"
        Me.DETAILSToolStripMenuItem1.Size = New System.Drawing.Size(123, 22)
        Me.DETAILSToolStripMenuItem1.Text = "DETAILS.."
        '
        'SOLDMEDICINEDETAILSToolStripMenuItem
        '
        Me.SOLDMEDICINEDETAILSToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.water_1330252__340
        Me.SOLDMEDICINEDETAILSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DETAILSToolStripMenuItem2})
        Me.SOLDMEDICINEDETAILSToolStripMenuItem.Name = "SOLDMEDICINEDETAILSToolStripMenuItem"
        Me.SOLDMEDICINEDETAILSToolStripMenuItem.Size = New System.Drawing.Size(151, 20)
        Me.SOLDMEDICINEDETAILSToolStripMenuItem.Text = "SOLD MEDICINE DETAILS"
        '
        'DETAILSToolStripMenuItem2
        '
        Me.DETAILSToolStripMenuItem2.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.lime_2481346__340
        Me.DETAILSToolStripMenuItem2.Name = "DETAILSToolStripMenuItem2"
        Me.DETAILSToolStripMenuItem2.Size = New System.Drawing.Size(123, 22)
        Me.DETAILSToolStripMenuItem2.Text = "DETAILS.."
        '
        'PHARMACYWHOLESALERSToolStripMenuItem
        '
        Me.PHARMACYWHOLESALERSToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.lime_2481346__340
        Me.PHARMACYWHOLESALERSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PHARMAHOPERSToolStripMenuItem})
        Me.PHARMACYWHOLESALERSToolStripMenuItem.Name = "PHARMACYWHOLESALERSToolStripMenuItem"
        Me.PHARMACYWHOLESALERSToolStripMenuItem.Size = New System.Drawing.Size(167, 20)
        Me.PHARMACYWHOLESALERSToolStripMenuItem.Text = "PHARMACY WHOLESALERS"
        '
        'PHARMAHOPERSToolStripMenuItem
        '
        Me.PHARMAHOPERSToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.water_1330252__340
        Me.PHARMAHOPERSToolStripMenuItem.Name = "PHARMAHOPERSToolStripMenuItem"
        Me.PHARMAHOPERSToolStripMenuItem.Size = New System.Drawing.Size(123, 22)
        Me.PHARMAHOPERSToolStripMenuItem.Text = "DETAILS.."
        '
        'EXITToolStripMenuItem
        '
        Me.EXITToolStripMenuItem.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.water_1330252__340
        Me.EXITToolStripMenuItem.Name = "EXITToolStripMenuItem"
        Me.EXITToolStripMenuItem.Size = New System.Drawing.Size(42, 20)
        Me.EXITToolStripMenuItem.Text = "EXIT"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(381, 224)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(370, 108)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "BILLING SYSTEM"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'list
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.pharmacy_management.My.Resources.Resources.pill_3069032_1920
        Me.ClientSize = New System.Drawing.Size(1138, 604)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "list"
        Me.Text = "list"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MEDICINECATEGORIESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FEVERToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents THYROIDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DIADETICSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CUSTOMERCATEGORIESToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DAILYToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MONTHLYToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EMPLOYEEDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DOCTORSDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DETAILSToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SOLDMEDICINEDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DETAILSToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PHARMACYWHOLESALERSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PHARMAHOPERSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
