﻿Imports System.Data.OleDb
Public Class whole1
    Dim con As OleDbConnection
    Dim com As OleDbCommand
    Private Sub whole1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MedicineDataSet.WHOLE' table. You can move, or remove it, as needed.
        Me.WHOLETableAdapter.Fill(Me.MedicineDataSet.WHOLE)
        Timer1.Start()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        WHOLEBindingSource.AddNew()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            WHOLEBindingSource.EndEdit()
            WHOLETableAdapter.Update(MedicineDataSet.WHOLE)
            MessageBox.Show("DATA SAVED")
        Catch ex As Exception
            MessageBox.Show("ERROR ON SAVING")
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\bcapro28\database\medicine.accdb;")
        com = New OleDbCommand("delete from WHOLE where WHOLESALERNAME=@WHOLESALERNAME", con)
        con.Open()
        com.Parameters.AddWithValue("WHOLESALERNAME", TextBox1.Text)
        com.ExecuteNonQuery()
        MessageBox.Show("DATA DELETED")
        con.Close()
        WHOLEBindingSource.RemoveCurrent()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\bcapro28\database\medicine.accdb;")
        Dim str As String = "update WHOLE set TABLETNAME=?,NUMBEROFTABLETS=?,TABLETPRICE=?,ISSUEDATE=? where WHOLESALERNAME=?"
        com = New OleDbCommand(str, con)
        con.Open()
        com.Parameters.AddWithValue("TABLETNAME", TextBox2.Text)
        com.Parameters.AddWithValue("NUMBEROFTABLETS", TextBox3.Text)
        com.Parameters.AddWithValue("TABLETPRICE", TextBox4.Text)
        com.Parameters.AddWithValue("ISSUEDATE", TextBox5.Text)
        com.Parameters.AddWithValue("WHOLESALERNAME", TextBox1.Text)
        com.ExecuteNonQuery()
        MessageBox.Show("DATA UPDATED")
        con.Close()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        WHOLEBindingSource.MoveFirst()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        WHOLEBindingSource.MovePrevious()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        WHOLEBindingSource.MoveNext()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        WHOLEBindingSource.MoveLast()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim count As Integer
        count = WHOLEBindingSource.Count
        Label7.Text = "There Are " + count.ToString + " Rows"
    End Sub

    Private Sub TextBox6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox6.TextChanged
        Me.WHOLEBindingSource.Filter = "TABLETNAME like'" & TextBox6.Text & "%'"
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\bcapro28\database\medicine.accdb;")
        Dim str As String = "insert into STOCK values (@TABLETNAME,@NUMBEROFTABLETS)"
        com = New OleDbCommand(str, con)
        con.Open()
        com.Parameters.AddWithValue("@TABLETNAME", TextBox2.Text)
        com.Parameters.AddWithValue("@NUMBEROFTABLETS", TextBox3.Text)
        com.ExecuteNonQuery()
        MessageBox.Show("Data Updated On Stock")
        con.Close()
    End Sub
End Class