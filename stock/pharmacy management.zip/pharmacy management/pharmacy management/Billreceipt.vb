﻿Imports System.Data.OleDb
Public Class Billreceipt
    Dim con As OleDbConnection
    Dim com As OleDbCommand
    Private Sub Billreceipt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MedicineDataSet.STOCK' table. You can move, or remove it, as needed.
        Me.STOCKTableAdapter.Fill(Me.MedicineDataSet.STOCK)
        'TODO: This line of code loads data into the 'MedicineDataSet.SOLD' table. You can move, or remove it, as needed.
        Me.SOLDTableAdapter.Fill(Me.MedicineDataSet.SOLD)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox5.Text = Val(TextBox3.Text) * Val(TextBox4.Text)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ListBox1.Items.Add(ComboBox3.Text)
        ListBox2.Items.Add(TextBox3.Text)
        ListBox3.Items.Add(TextBox4.Text)
        ListBox4.Items.Add(TextBox5.Text)
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim total As Integer
        Dim i As Integer
        For i = 0 To ListBox4.Items.Count - 1
            total = total + Val(ListBox4.Items(i))
        Next
        Label11.Text = total
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If ListBox1.Items.Count = 0 And ListBox2.Items.Count = 0 And ListBox3.Items.Count = 0 And ListBox4.Items.Count = 0 Then
            MsgBox("You Can't Create Receipt...! ", MsgBoxStyle.Critical, " ")
        Else
            Dim obj As New receipt
            Dim itemlist1 As New List(Of String)
            Dim itemlist2 As New List(Of String)
            Dim itemlist3 As New List(Of String)
            Dim itemlist4 As New List(Of String)
            For Each i In ListBox1.Items
                itemlist1.Add(i.ToString)
            Next
            For Each i In ListBox2.Items
                itemlist2.Add(i.ToString)
            Next
            For Each k In ListBox3.Items
                itemlist3.Add(k.ToString)
            Next
            For Each l In ListBox4.Items
                itemlist4.Add(l.ToString)
            Next
            obj.namepass = TextBox2.Text
            obj.datepass = TextBox1.Text
            obj.amount = Label11.Text
            obj.itemlist1 = itemlist1
            obj.itemlist2 = itemlist2
            obj.itemlist3 = itemlist3
            obj.itemlist4 = itemlist4
            obj.Show()
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If (Val(TextBox6.Text) > Val(TextBox3.Text)) Then
            con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\bcapro28\database\medicine.accdb;")
            TextBox6.Text = Val(TextBox6.Text) - Val(TextBox3.Text)
            Dim str As String = "update STOCK set NUMBEROFTABLETS=? where TABLETNAME=? "
            com = New OleDbCommand(str, con)
            con.Open()
            com.Parameters.AddWithValue("NUMBEROFTABLETS", TextBox6.Text)
            com.Parameters.AddWithValue("TABLETNAME", ComboBox2.Text)
            com.ExecuteNonQuery()
            MessageBox.Show("Current Stock Is Updated")
            con.Close()
        Else
            MessageBox.Show("You Have Limited Stock Only")

        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        cEXIT.ExitSystem()
    End Sub
End Class