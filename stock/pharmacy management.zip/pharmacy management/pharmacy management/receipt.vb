﻿Public Class receipt

    Public Property namepass As String
    Public Property datepass As String
    Public Property amount As String
    Public itemlist1 As List(Of String)
    Public itemlist2 As List(Of String)
    Public itemlist3 As List(Of String)
    Public itemlist4 As List(Of String)


    Private Sub receipt_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        Billreceipt.ListBox1.Items.Add(Me.ListBox1.Items)
        Billreceipt.ListBox2.Items.Add(Me.ListBox2.Items)
        Billreceipt.ListBox3.Items.Add(Me.ListBox3.Items)
        Billreceipt.ListBox4.Items.Add(Me.ListBox4.Items)
    End Sub

    Private Sub receipt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label1.Text = namepass
        Label2.Text = datepass
        Label8.Text = amount
        ListBox1.DataSource = itemlist1
        ListBox2.DataSource = itemlist2
        ListBox3.DataSource = itemlist3
        ListBox4.DataSource = itemlist4
    End Sub
End Class