﻿Imports System.Data.OleDb
Public Class employee
    Dim con As OleDbConnection
    Dim com As New OleDbCommand
    Private Sub employee_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DetailsDataSet.EMP' table. You can move, or remove it, as needed.
        Me.EMPTableAdapter.Fill(Me.DetailsDataSet.EMP)
        Timer1.Start()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        EMPBindingSource.AddNew()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            EMPBindingSource.EndEdit()
            EMPTableAdapter.Update(DetailsDataSet.EMP)
            MessageBox.Show("DATA SAVED")
        Catch ex As Exception
            MessageBox.Show("ERROR ON SAVING")
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=D:\bcapro28\database\details.accdb;")
        com = New OleDbCommand("delete from EMP where EMPLOYEENAME=@EMPLOYEENAME", con)
        Try
            con.Open()
            com.Connection = con
            com.Parameters.AddWithValue("@EMPLOYEENAME", TextBox1.Text)
            com.ExecuteNonQuery()
            MessageBox.Show("DELETED")
            con.Close()
            EMPBindingSource.RemoveCurrent()
        Catch ex As Exception
            MessageBox.Show("ERROR")
        End Try
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        EMPBindingSource.MoveFirst()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        EMPBindingSource.MovePrevious()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        EMPBindingSource.MoveNext()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        EMPBindingSource.MoveLast()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\bcapro28\database\details.accdb;")
        Dim str As String = "update EMP set ADDRESS=?,CITY=?,EDUCATION=?,LEAVETAKENDAYS=?,SALARY=?,SALARYGAINEDDATE=?,PHONENUMBER=?,MAILID=? where EMPLOYEENAME=?"
        com = New OleDbCommand(str, con)
        Try
            con.Open()
            com.Parameters.AddWithValue("?", TextBox2.Text)
            com.Parameters.AddWithValue("?", TextBox3.Text)
            com.Parameters.AddWithValue("?", TextBox4.Text)
            com.Parameters.AddWithValue("?", TextBox5.Text)
            com.Parameters.AddWithValue("?", TextBox6.Text)
            com.Parameters.AddWithValue("?", TextBox7.Text)
            com.Parameters.AddWithValue("?", TextBox8.Text)
            com.Parameters.AddWithValue("?", TextBox9.Text)
            com.Parameters.AddWithValue("?", TextBox1.Text)
            com.ExecuteNonQuery()
            MessageBox.Show("DATA UPDATED")
            con.Close()
        Catch ex As Exception
            MessageBox.Show("ERROR ON UPDATION")
        End Try
       
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim count As Integer
        count = EMPBindingSource.Count
        Label11.Text = "There Are " + count.ToString + " Rows"
    End Sub

    Private Sub TextBox8_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox8.LostFocus
        If Trim(TextBox8.Text).Length < 10 Then
            MsgBox("phone number must be of 10 digits...! ", MsgBoxStyle.Critical, "ERROR IN PHONE NUMBER")
        End If
    End Sub
End Class