﻿Public Class list
    Private Sub EXITToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXITToolStripMenuItem.Click
        cEXIT.ExitSystem()
    End Sub

    Private Sub FEVERToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FEVERToolStripMenuItem.Click
        fevermed.Show()
    End Sub

    Private Sub THYROIDToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles THYROIDToolStripMenuItem.Click
        thyroidmed.Show()
    End Sub

    Private Sub DIADETICSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DIADETICSToolStripMenuItem.Click
        diabet.Show()
    End Sub

    Private Sub DAILYToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DAILYToolStripMenuItem.Click
        dailycusform.Show()
    End Sub

    Private Sub MONTHLYToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MONTHLYToolStripMenuItem.Click
        monthlycusform.Show()
    End Sub

    Private Sub DETAILSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DETAILSToolStripMenuItem.Click
        employee.Show()
    End Sub

    Private Sub DETAILSToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DETAILSToolStripMenuItem1.Click
        doctor.Show()
    End Sub

    Private Sub DETAILSToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DETAILSToolStripMenuItem2.Click
        sold.Show()
    End Sub

    Private Sub PHARMAHOPERSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PHARMAHOPERSToolStripMenuItem.Click
        whole1.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Billreceipt.Show()
    End Sub
End Class