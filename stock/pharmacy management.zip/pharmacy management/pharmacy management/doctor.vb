﻿Imports System.Data.OleDb
Public Class doctor
    Dim con As OleDbConnection
    Dim com As OleDbCommand
    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub


    Private Sub doctor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DetailsDataSet.DOCTOR' table. You can move, or remove it, as needed.
        Me.DOCTORTableAdapter.Fill(Me.DetailsDataSet.DOCTOR)
        Timer1.Start()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        DOCTORBindingSource.AddNew()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            DOCTORBindingSource.EndEdit()
            DOCTORTableAdapter.Update(DetailsDataSet.DOCTOR)
            MessageBox.Show("DATA SAVED")
        Catch ex As Exception
            MessageBox.Show("ERROR ON SAVING")
        End Try

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        DOCTORBindingSource.MoveFirst()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        DOCTORBindingSource.MovePrevious()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        DOCTORBindingSource.MoveNext()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        DOCTORBindingSource.MoveLast()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=D:\bcapro28\database\details.accdb;")
        com = New OleDbCommand("delete from DOCTOR where DOCTORNAME=@DOCTORNAME", con)
        Try
            con.Open()
            com.Connection = con
            com.Parameters.AddWithValue("@DOCTORNAME", TextBox1.Text)
            com.ExecuteNonQuery()
            MessageBox.Show("DATA DELETED")
            con.Close()
            DOCTORBindingSource.RemoveCurrent()
        Catch ex As Exception
            MessageBox.Show("ERROR ON DELETION")
        End Try
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\bcapro28\database\details.accdb;")
        Dim str As String = "update DOCTOR set MEDICALCENTRENAME=?,MEDICALCCENTREADDRESS=?,SPECIALISTTYPE=?,AVAILABILETIME=?,PHONEMUNBER=?,MAILID=? where DOCTORNAME=?"
        com = New OleDbCommand(str, con)
        '  Try
        con.Open()
        com.Parameters.AddWithValue("MEDICALCENTRENAME", TextBox2.Text)
        com.Parameters.AddWithValue("MEDICALCCENTREADDRESS", TextBox3.Text)
        com.Parameters.AddWithValue("SPECIALISTTYPE", TextBox4.Text)
        com.Parameters.AddWithValue("AVAILABILETIME", TextBox5.Text)
        com.Parameters.AddWithValue("PHONENUMBER", TextBox6.Text)
        com.Parameters.AddWithValue("MAILID", TextBox7.Text)
        com.Parameters.AddWithValue("DOCTORNAME", TextBox1.Text)
        com.ExecuteNonQuery()
        MessageBox.Show("DATA UPDATED")
        con.Close()
        ' Catch ex As Exception
        'MessageBox.Show("ERROR ON UPDATION")
       ' End Try
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim count As Integer
        count = DOCTORBindingSource.Count
        Label8.Text = "There Are " + count.ToString + " Rows"
    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged
        Me.DOCTORBindingSource.Filter = "DOCTORNAME like'%" & TextBox8.Text & "%'"
    End Sub

    Private Sub TextBox6_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox6.LostFocus
        If Trim(TextBox6.Text).Length < 10 Then
            MsgBox("phone number must be of 10 digits...! ", MsgBoxStyle.Critical, "ERROR IN PHONE NUMBER")
        End If
    End Sub
End Class