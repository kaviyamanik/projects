﻿Imports System.Data.OleDb
Public Class monthlycusform
    Dim con As OleDbConnection
    Dim com As OleDbCommand
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MONTHLYBindingSource.AddNew()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            MONTHLYBindingSource.EndEdit()
            MONTHLYTableAdapter.Update(DetailsDataSet.MONTHLY)
            MessageBox.Show("DATA SAVED")
        Catch ex As Exception
            MessageBox.Show("ERROR")
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        MONTHLYBindingSource.MoveFirst()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        MONTHLYBindingSource.MovePrevious()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        MONTHLYBindingSource.MoveNext()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        MONTHLYBindingSource.MoveLast()
    End Sub

    Private Sub monthlycusform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DetailsDataSet.MONTHLY' table. You can move, or remove it, as needed.
        Me.MONTHLYTableAdapter.Fill(Me.DetailsDataSet.MONTHLY)
        Timer1.Start()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=D:\bcapro28\database\details.accdb;")
        com = New OleDbCommand("delete from MONTHLY where CUSTOMERNAME=@CUSTOMERNAME", con)
        Try
            con.Open()
            com.Connection = con
            com.Parameters.AddWithValue("@CUSTOMERNAME", TextBox1.Text)
            com.ExecuteNonQuery()
            MessageBox.Show("DELETED")
            con.Close()
            MONTHLYBindingSource.RemoveCurrent()
        Catch ex As Exception
            MessageBox.Show("ERROR")
        End Try
    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged
        Me.MONTHLYBindingSource.Filter = "CUSTOMERNAME like'%" & TextBox8.Text & "%'"

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim count As Integer
        count = MONTHLYBindingSource.Count
        Label10.Text = "There are " + count.ToString + " Rows"
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=D:\bcapro28\database\details.accdb;")
        Dim str As String = "update MONTHLY set ADDRESS=?,CITY=?,CONSULTEDDOCTOR=?,TABLETFOR=?,PHONENUMBER=?,MAILID=? where CUSTOMERNAME=?"
        com = New OleDbCommand(str, con)
        Try
            con.Open()
            com.Parameters.AddWithValue("ADDRESS", TextBox2.Text)
            com.Parameters.AddWithValue("CITY", TextBox3.Text)
            com.Parameters.AddWithValue("CONSULTEDDOCTOR", TextBox4.Text)
            com.Parameters.AddWithValue("TABLETFOR", TextBox5.Text)
            com.Parameters.AddWithValue("PHONENUMBER", TextBox6.Text)
            com.Parameters.AddWithValue("MAILID", TextBox7.Text)
            com.Parameters.AddWithValue("CUSTOMERNAME", TextBox1.Text)
            com.ExecuteNonQuery()
            MessageBox.Show("DATA UPDATED")
            con.Close()
        Catch ex As Exception
            MessageBox.Show("ERROR ON UPDATION")
        End Try
    End Sub

    Private Sub TextBox6_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox6.LostFocus
        If Trim(TextBox6.Text).Length < 10 Then
            MsgBox("phone number must be of 10 digits...! ", MsgBoxStyle.Critical, "ERROR IN PHONE NUMBER")
        End If
    End Sub
End Class