﻿Imports System.Data.OleDb
Public Class sold
    Dim con As OleDbConnection
    Dim com As OleDbCommand
    Private Sub sold_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MedicineDataSet.SOLD' table. You can move, or remove it, as needed.
        Me.SOLDTableAdapter.Fill(Me.MedicineDataSet.SOLD)
        'TODO: This line of code loads data into the 'MedicineDataSet.SOLD' table. You can move, or remove it, as needed.
        Me.SOLDTableAdapter.Fill(Me.MedicineDataSet.SOLD)
        Timer1.Start()
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        SOLDBindingSource.AddNew()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            SOLDBindingSource.EndEdit()
            SOLDTableAdapter.Update(MedicineDataSet.SOLD)
            MessageBox.Show("DATA SAVED")
        Catch ex As Exception
            MessageBox.Show("ERROR ON SAVING")
        End Try
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        TextBox6.Text = Val(TextBox4.Text) * (TextBox5.Text)
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\16302628Project\bcapro28\database\medicine.accdb;")
        com = New OleDbCommand("delete from SOLD where CUSTOMERNAME=@CUSTOMERNAME", con)
        con.Open()
        com.Parameters.AddWithValue("CUSTOMERNAME", TextBox1.Text)
        com.ExecuteNonQuery()
        MessageBox.Show("DATA DELETED")
        con.Close()
        SOLDBindingSource.RemoveCurrent()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.Close()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim count As Integer
        count = SOLDBindingSource.Count
        Label6.Text = "There Are " + count.ToString + " Rows"
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        SOLDBindingSource.MoveFirst()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        SOLDBindingSource.MovePrevious()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        SOLDBindingSource.MoveNext()
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        SOLDBindingSource.MoveLast()
    End Sub

    Private Sub TextBox7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox7.TextChanged
        Me.SOLDBindingSource.Filter = "CUSTOMERNAME like '%" & TextBox7.Text & "%'"
    End Sub
End Class