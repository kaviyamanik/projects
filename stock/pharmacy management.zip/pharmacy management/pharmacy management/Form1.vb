﻿Public Class Form1

    Private Sub Form1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        login.Show()
        Me.Hide()
    End Sub
End Class
