﻿Public Class login

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        cEXIT.ExitSystem()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MessageBox.Show("UserName Or Password Cannot Be Blank")
        ElseIf TextBox1.Text = "Admin" And TextBox2.Text = "kaviya" Then
            TextBox1.Text = ""
            TextBox2.Text = ""
            MessageBox.Show("LOGIN SUCCESS")
            Me.Hide()
            list.Show()
        Else
            TextBox1.Text = ""
            TextBox2.Text = ""
            MessageBox.Show("LOGIN FAILED")
        End If
    End Sub
End Class